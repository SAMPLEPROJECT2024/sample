Happy Birthday

A Happy Birthday animation design in CSS3, HTML5.




